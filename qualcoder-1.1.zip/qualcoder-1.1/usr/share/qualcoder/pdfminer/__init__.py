#!/usr/bin/env python3
__version__ = '1.3.1'

if __name__ == '__main__': print(__version__)
