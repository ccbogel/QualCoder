# QualCoder
QualCoder is a qualitative data analysis application written in python3 and pyqt5.

QualCoder projects are stored in a Sqlite database. Text files can be typed in manually or loaded from txt, odt, docx and optionally ,and not ideally, pdf files. Images, audio and video can also be coded. Codes can be assigned to text and to images and grouped into categories in hierarchical fashion similar to Nvivo. Various types of reports can be produced including visual coding graphs, coder comparisons and coding frequencies.

Instructions and other information are avaible here: https://qualcoder.wordpress.com/

## INSTALLATION


## Dependencies
Required

* Python 3.x version

* PyQt5

* lxml

* VLC

* qpdf

## Issues
* Testing has only been performed on Ubuntu, 18 Linux Mint 18, Windows 10 and parly on Lubuntu 16.

## Future plans
* Reports:
    * Word count report
    * possibly look at text mining

## License
QualCoder is distributed under the MIT LICENSE.
